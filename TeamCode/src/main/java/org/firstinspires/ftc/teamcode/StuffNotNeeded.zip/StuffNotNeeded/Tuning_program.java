package org.firstinspires.ftc.teamcode.StuffNotNeeded;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.CompBotW3.CompBotW3Attachments;

@TeleOp
public class Tuning_program extends OpMode {
    CompBotW3Attachments r = new CompBotW3Attachments();
    double pCoeff = 0.02, dCoeff = 0, iCoeff = 0, fp = 0.5, sp = 0, rp = 0.5;
    ElapsedTime e = new ElapsedTime();
    double initialHeading, pastError = 0, intError = 0;

    @Override
    public void init() {
        r.init(hardwareMap,telemetry);
        initialHeading = r.imu.getHeading();
    }

    @Override
    public void loop() {
        double elapsedTime = e.milliseconds();
        e.reset(); // Reset the timer
        double error = r.imu.getHeading() - initialHeading;
        double dervError = (error-pastError)/elapsedTime;
        intError += error*elapsedTime/1000;
        double totalError = (pCoeff*error + dCoeff*dervError + iCoeff*intError);
        r.fl.setPower(-(fp + sp + totalError));
        r.fr.setPower(fp - sp - totalError);
        r.bl.setPower(-(fp - sp + totalError));
        r.br.setPower(fp + sp - totalError); // If the motor is finished, apply only the correction (flip flops signs because we're in RUN_TO_POSITION mode)
        pastError = error; // Move error into pastError for next loop

        if(gamepad1.dpad_up) {
            fp=rp;
            sp=0;
        } if(gamepad1.dpad_right) {
            fp=0;
            sp=rp;
        } if(gamepad1.dpad_down) {
            fp=-rp;
            sp=0;
        } if(gamepad1.dpad_left) {
            fp=0;
            sp=-rp;
        } if(gamepad1.left_bumper) {
            fp=0;
            sp=0;
        }

        if(gamepad1.a) {
            pCoeff+=0.0001;
        } if(gamepad1.b) {
            pCoeff-=0.0001;
        } if(gamepad1.x) {
            dCoeff+=0.0001;
        } if(gamepad1.y) {
            dCoeff -= 0.0001;
        }
        iCoeff += 0.00001*gamepad1.right_stick_y;

        telemetry.addData("pC", pCoeff);
        telemetry.addData("dC", dCoeff);
        telemetry.addData("iC",iCoeff);
        telemetry.addData("error",error);
        telemetry.addData("totalError",totalError);
        telemetry.update();
    }
}
