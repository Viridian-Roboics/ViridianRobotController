package org.firstinspires.ftc.teamcode.StuffNotNeeded;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import org.firstinspires.ftc.teamcode.CompBotW3.CompBotW3Attachments;

@Autonomous
public class yayayayya extends LinearOpMode {
    CompBotW3Attachments r = new CompBotW3Attachments();
    @Override
    public void runOpMode() throws InterruptedException {
        r.init(hardwareMap,telemetry);

        waitForStart();

        r.AEncDrive(0,40,0.5,10000);
    }
}
